<?php
      $conn = mysql_connect('localhost', 'root', '');
	  $db   = mysql_select_db('people');
?>